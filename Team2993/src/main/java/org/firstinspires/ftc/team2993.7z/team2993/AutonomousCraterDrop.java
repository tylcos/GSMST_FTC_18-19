package org.firstinspires.ftc.team2993;

import com.disnodeteam.dogecv.CameraViewDisplay;
import com.disnodeteam.dogecv.DogeCV;
import com.disnodeteam.dogecv.detectors.roverrukus.GoldAlignDetector;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;


@TeleOp(name="Auto - Crater Drop", group="crater")
public class AutonomousCraterDrop extends LinearOpMode
{
    private RobotHardware robot;
    private GoldAlignDetector detector;
    ElapsedTime timer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);



    @Override
    public void runOpMode()
    {
        robot = new RobotHardware(hardwareMap);
        setupDetector();



        waitForStart();



        robot.lift.setPower(.5);
        wait(4000);
        robot.lift.setPower(0);

        Drive(1, 400 , 0);


        int cheesePos = 1;
        if (!detector.isFound())
            cheesePos = 0;
        else if (detector.getXPosition() >= 320)
            cheesePos = 2;
        else if (detector.getXPosition() < 320)
            cheesePos = 1;
        wait(500);

        Turn(1, 600, 2000);
        Drive(1, 2000, 0);
    }



    public void Turn(int direction, int time, int extraWait)
    {
        robot.Drive(-direction, direction);
        wait(time);
        robot.Drive(0d);
        wait(extraWait);
    }

    public void Drive(int direction, int time, int extraWait)
    {
        robot.Drive(.5 * direction, .5 * direction);
        wait(time);
        robot.Drive(0d);
        wait(extraWait);
    }



    public void wait (int ms)
    {
        timer.reset();
        while (timer.time() < ms && opModeIsActive())
            idle();
    }

    public void setupDetector()
    {/*
        telemetry.addData("Status", "Lets get that bread!");

        // Set up detector
        detector = new GoldAlignDetector(); // Create detector
        detector.init(hardwareMap.appContext, CameraViewDisplay.getInstance()); // Initialize it with the app context and camera
        detector.useDefaults(); // Set detector to use default settings

        // Optional tuning
        detector.alignSize = 100; // How wide (in pixels) is the range in which the gold object will be aligned. (Represented by green bars in the preview)
        detector.alignPosOffset = 0; // How far from center frame to offset this alignment zone.
        detector.downscale = 0.4; // How much to downscale the input frames

        detector.areaScoringMethod = DogeCV.AreaScoringMethod.MAX_AREA;
        detector.maxAreaScorer.weight = 0.005; //

        detector.ratioScorer.weight = 5; //
        detector.ratioScorer.perfectRatio = 1.0; // Ratio adjustment

        detector.enable();*/
    }
}