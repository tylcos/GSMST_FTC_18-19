package org.firstinspires.ftc.team2993;

public class Power
{
    public double up, down;

    public Power (double Up, double Down)
    {
        up = Up;
        down = Down;
    }
}
